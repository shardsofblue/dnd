#######################
#### Load Packages ####
#######################

library(tidyverse)
library(stringr)
library(lubridate)
library(readxl)
library(janitor)
library(weathermetrics)

##############################
##### LOAD DATA ##############
##############################


# Load Baltimore Inner Harbor Temperature Data
bwi_data <- read_csv("scripts/td/baltimore-bwi-temperature/BWI.csv")

# Load Baltimore Inner Harbor Temperature Data
inner_harbor_data <- read_excel("scripts/td/baltimore-inner-harbor-temperature/DMH.xlsx")

##############################
##### CLEAN DATA #############
##############################

# Clean BWI data 
bwi_data <- bwi_data %>%
  filter(tmpf != 'M', dwpf != 'M') %>%
  mutate(tmpf = as.numeric(tmpf),
         dwpf = as.numeric(dwpf)) %>%
  mutate(date = as.Date(valid, format="%Y-%m-%d")) %>%
  mutate(year=year(valid)) %>%
  mutate(month=month(valid)) %>%
  mutate(hour=hour(valid)) %>%
  mutate(day=day(valid)) %>%
  mutate(hour=hour(valid)) %>%
  distinct(valid, .keep_all = TRUE) %>%
  mutate(heat_index = heat.index(t=tmpf, dp=dwpf, temperature.metric = "fahrenheit", round=0)) %>%
  mutate(relative_humidity = dewpoint.to.humidity(dp = dwpf, t = tmpf, temperature.metric = "fahrenheit")) %>%
  select(date, year, month, day, hour, tmpf, dwpf, relative_humidity, heat_index) %>%
  group_by(date, year, month, day, hour) %>%
  summarise(avg_hourly_temperature = mean(tmpf),
            avg_hourly_dewpoint = mean(dwpf),
            avg_hourly_relative_humidity = mean(relative_humidity),
            avg_hourly_heat_index = mean(heat_index)
  ) %>%
  filter(!is.na(avg_hourly_relative_humidity)) %>%
  distinct()

# Clean Inner Harbor data 

inner_harbor_data <- inner_harbor_data %>%
  filter(TEMPERATURE != 'M', DEW_POINT != 'M') %>%
  mutate(TEMPERATURE = as.numeric(TEMPERATURE),
         DEW_POINT = as.numeric(DEW_POINT)) %>%
  mutate(date = as.Date(DATETIME, format="%Y-%m-%d")) %>%
  mutate(year=year(DATETIME)) %>%
  mutate(month=month(DATETIME)) %>%
  mutate(hour=hour(DATETIME)) %>%
  mutate(day=day(DATETIME)) %>%
  mutate(hour=hour(DATETIME)) %>%
  distinct(DATETIME, .keep_all = TRUE) %>%
  mutate(heat_index = heat.index(t=TEMPERATURE, dp=DEW_POINT, temperature.metric = "fahrenheit", round=0)) %>%
  mutate(relative_humidity = dewpoint.to.humidity(dp = DEW_POINT, t = TEMPERATURE, temperature.metric = "fahrenheit")) %>%
  select(date, year, month, day, hour, TEMPERATURE, DEW_POINT, relative_humidity, heat_index) %>%
  group_by(date, year, month, day, hour) %>%
  summarise(avg_hourly_temperature = mean(TEMPERATURE),
            avg_hourly_dewpoint = mean(DEW_POINT),
            avg_hourly_relative_humidity = mean(relative_humidity),
            avg_hourly_heat_index = mean(heat_index)
  ) %>%
  filter(!is.na(avg_hourly_relative_humidity)) %>%
  distinct()


###########################################
###### Adjust Inner Harbor Temperatures####
###########################################

# We have 75 years of dew point and temperature data for BWI, which allows us to calculate heat index
# We have 20 years of dew point and temperature data for DMH (Inner Harbor), which allows us to calculate heat index. 
# I talked with Dan Li, a climate researcher at Boston University who has studied variation in urban heat island temperatures between suburbs in different seasons and different hours of the day, who said a pretty good way to calculate the difference would be this:
# 1. Join the 20 years of DMH data to the 20 years of BWI data.  Join on date and hour, so we end up with a data frame of values for both DMH and BWI for each date and hour in our data set.  Do an inner join, so that if for some reason DMH is missing an hour from its data set (or vice versa), it doesn't mess up our averages. 
# 2. Calculate new columns with difference in temperature, dew point, relative humidity and heat index between BWI and DMH.  Since in almost all cases BWI will be colder than DMH, make it so the difference is positive if DMH is greater than BWI. 
# 3. Create a new column assigning each date/hour to a given season (i.e. January 1 at 3 am is winter). 
# 4. Group by season and hour and calculate the AVERAGE difference in temperature, dew point, relative humidity and heat index. 
# 5. Armed with this data, now go back to the original 75 years of BWI data (after it's been cleaned, not on raw import).  Create a column for season in this data.  Then write a pretty indepth case when function (or, I dunno, there may be a better way to do this), that adjusts the temperature and dew point values based on table created in step 4. Don't do heat index or relative humidity, we're going to redo those with our new dew point values. 
#6. Create two new columns to recalculate heat index and relative humidity (see cleaning function above, weathermetrics package has a nice way of doing this). Call them adjusted_heat_index, adjusted_relative_humidity 
#7. DONE! 


###########################################
###### QUESTIONS ##########################
###########################################

# Our goal is to find out how frequent extremely high temperatures have been in Baltimore over the last century. 
# What have the patterns been with 90+, 103+ heat index days -- key values for heat index? What years have had the most of these days? What have the longest stretches been? Are there more recently that have been intense?
# Have the hottest months of the year (July, August) gotten more hot on average?
# How many days have not had a heat index BELOW 80 degrees, even at night? Are there more frequent recent stretches

##################
#### RANDOM CODE THAT MIGHT BE HELPFUL#
##################

daily_summary_stats <- bwi_data %>%
  group_by(date) %>%
  summarise(avg_daily_temperature = mean(avg_hourly_temperature),
            avg_daily_dewpoint = mean(avg_hourly_dewpoint),
            avg_daily_relative_humidity = mean(avg_hourly_relative_humidity),
            avg_daily_heat_index = mean(avg_hourly_heat_index),
            max_daily_temperature = max(avg_hourly_temperature),
            max_daily_dewpoint = max(avg_hourly_dewpoint),
            max_daily_relative_humidity = max(avg_hourly_relative_humidity),
            max_daily_heat_index = max(avg_hourly_heat_index)
  ) 

days_index_90_plus <- daily_summary_stats %>%
  filter(max_daily_heat_index >= 90)

year_days_index_90_plus <- days_index_90_plus %>%
  group_by(year(date)) %>%
  summarise(count=n())

barplot(year_days_index_90_plus$count)


daily_summary_stats <- temp_data %>%
  group_by(date) %>%
  summarise(avg_daily_temperature = mean(avg_hourly_temperature),
            avg_daily_dewpoint = mean(avg_hourly_dewpoint),
            avg_daily_relative_humidity = mean(avg_hourly_relative_humidity),
            avg_daily_heat_index = mean(avg_hourly_heat_index),
            max_daily_temperature = max(avg_hourly_temperature),
            max_daily_dewpoint = max(avg_hourly_dewpoint),
            max_daily_relative_humidity = max(avg_hourly_relative_humidity),
            max_daily_heat_index = max(avg_hourly_heat_index)
  ) 



test <- daily_summary_stats %>%
  filter(is.na(avg_daily_relative_humidity))

monthly_summary_stats <- temp_data %>%
  group_by(month) %>%
  summarise(avg_monthly_temperature = mean(avg_hourly_temperature),
            avg_monthly_dewpoint = mean(avg_hourly_dewpoint),
            avg_monthly_relative_humidity = mean(avg_hourly_relative_humidity),
            avg_monthly_heat_index = mean(avg_hourly_heat_index),
            max_monthly_temperature = max(avg_hourly_temperature),
            max_monthly_dewpoint = max(avg_hourly_dewpoint),
            max_monthly_relative_humidity = max(avg_hourly_relative_humidity),
            max_monthly_heat_index = max(avg_hourly_heat_index)
  ) 

year_month_summary_stats <- temp_data %>%
  group_by(year, month) %>%
  summarise(avg_daily_temperature = mean(avg_hourly_temperature),
            avg_daily_dewpoint = mean(avg_hourly_dewpoint),
            avg_daily_relative_humidity = mean(avg_hourly_relative_humidity),
            avg_daily_heat_index = mean(avg_hourly_heat_index),
            max_daily_temperature = max(avg_hourly_temperature),
            max_daily_dewpoint = max(avg_hourly_dewpoint),
            max_daily_relative_humidity = max(avg_hourly_relative_humidity),
            max_daily_heat_index = max(avg_hourly_heat_index)
  ) 

temp_data <- temp_data %>%
  group_by(year, month) %>%
  summarise(count = n()) %>%
  arrange(year, month)

